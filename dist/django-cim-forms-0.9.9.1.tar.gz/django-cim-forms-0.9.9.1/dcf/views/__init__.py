__author__="allyn.treshansky"
__date__ ="$Jan 31, 2013 12:44:59 PM$"

from dcf.utils import *

from views_index        import index
from views_customize    import customize, customize_instructions
from views_ajax         import get_category, edit_category, delete_category
from views_error        import error
from views_test         import test

