# -*- coding: utf-8 -*-
from south.utils import datetime_utils as datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models


class Migration(SchemaMigration):

    def forwards(self, orm):
        # Removing unique constraint on 'MetadataStandardCategoryCustomizer', fields ['name', 'project', 'proxy']
        db.delete_unique(u'questionnaire_metadatastandardcategorycustomizer', ['name', 'project_id', 'proxy_id'])

        # Removing unique constraint on 'MetadataScientificPropertyProxy', fields ['model_proxy', 'name']
        db.delete_unique(u'questionnaire_metadatascientificpropertyproxy', ['model_proxy_id', 'name'])

        # Deleting model 'NewModel'
        db.delete_table(u'questionnaire_newmodel')

        # Deleting model 'MyModel'
        db.delete_table(u'questionnaire_mymodel')

        # Deleting model 'TreeModel'
        db.delete_table(u'questionnaire_treemodel')

        # Adding model 'MetadataModel'
        db.create_table(u'questionnaire_metadatamodel', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('parent', self.gf('mptt.fields.TreeForeignKey')(blank=True, related_name='children', null=True, to=orm['questionnaire.MetadataModel'])),
            ('created', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('last_modified', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('proxy', self.gf('django.db.models.fields.related.ForeignKey')(related_name='models', null=True, to=orm['questionnaire.MetadataModelProxy'])),
            ('project', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='models', null=True, to=orm['questionnaire.MetadataProject'])),
            ('version', self.gf('django.db.models.fields.related.ForeignKey')(related_name='models', null=True, to=orm['questionnaire.MetadataVersion'])),
            ('is_document', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('is_root', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('vocabulary_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('component_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('title', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('active', self.gf('django.db.models.fields.BooleanField')(default=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('description', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            (u'lft', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'rght', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'tree_id', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'level', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
        ))
        db.send_create_signal('questionnaire', ['MetadataModel'])

        # Adding model 'MetadataScientificCategoryCustomizer'
        db.create_table(u'questionnaire_metadatascientificcategorycustomizer', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('created', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('last_modified', self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True)),
            ('pending_deletion', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('model_customizer', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='scientific_property_category_customizers', null=True, to=orm['questionnaire.MetadataModelCustomizer'])),
            ('proxy', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['questionnaire.MetadataScientificCategoryProxy'], null=True, blank=True)),
            ('project', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='model_scientific_category_customizers', null=True, to=orm['questionnaire.MetadataProject'])),
            ('vocabulary_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('component_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('model_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=512)),
            ('key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('description', self.gf('django.db.models.fields.TextField')(null=True, blank=True)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
        ))
        db.send_create_signal('questionnaire', ['MetadataScientificCategoryCustomizer'])

        # Adding unique constraint on 'MetadataScientificCategoryCustomizer', fields ['name', 'project', 'proxy', 'vocabulary_key', 'component_key', 'model_customizer']
        db.create_unique(u'questionnaire_metadatascientificcategorycustomizer', ['name', 'project_id', 'proxy_id', 'vocabulary_key', 'component_key', 'model_customizer_id'])

        # Adding model 'MetadataScientificCategoryProxy'
        db.create_table(u'questionnaire_metadatascientificcategoryproxy', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('description', self.gf('django.db.models.fields.TextField')(null=True, blank=True)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('component', self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='categories', null=True, to=orm['questionnaire.MetadataComponentProxy'])),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=512)),
            ('key', self.gf('django.db.models.fields.CharField')(max_length=512)),
        ))
        db.send_create_signal('questionnaire', ['MetadataScientificCategoryProxy'])

        # Adding unique constraint on 'MetadataScientificCategoryProxy', fields ['component', 'name']
        db.create_unique(u'questionnaire_metadatascientificcategoryproxy', ['component_id', 'name'])

        # Adding model 'MetadataComponentProxy'
        db.create_table(u'questionnaire_metadatacomponentproxy', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('documentation', self.gf('django.db.models.fields.TextField')(null=True, blank=True)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('vocabulary', self.gf('django.db.models.fields.related.ForeignKey')(related_name='component_proxies', null=True, to=orm['questionnaire.MetadataVocabulary'])),
            ('parent', self.gf('mptt.fields.TreeForeignKey')(blank=True, related_name='children', null=True, to=orm['questionnaire.MetadataComponentProxy'])),
            (u'lft', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'rght', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'tree_id', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'level', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
        ))
        db.send_create_signal('questionnaire', ['MetadataComponentProxy'])

        # Adding unique constraint on 'MetadataComponentProxy', fields ['vocabulary', 'name']
        db.create_unique(u'questionnaire_metadatacomponentproxy', ['vocabulary_id', 'name'])

        # Adding model 'MetadataScientificProperty'
        db.create_table(u'questionnaire_metadatascientificproperty', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('field_type', self.gf('django.db.models.fields.CharField')(max_length=64, blank=True)),
            ('is_label', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('model', self.gf('django.db.models.fields.related.ForeignKey')(related_name='scientific_properties', null=True, to=orm['questionnaire.MetadataModel'])),
            ('proxy', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['questionnaire.MetadataScientificPropertyProxy'], null=True, blank=True)),
            ('is_enumeration', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('category_key', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('atomic_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('enumeration_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('enumeration_other_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('extra_standard_name', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
            ('extra_description', self.gf('django.db.models.fields.TextField')(null=True, blank=True)),
            ('extra_units', self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True)),
        ))
        db.send_create_signal('questionnaire', ['MetadataScientificProperty'])

        # Adding model 'MetadataStandardProperty'
        db.create_table(u'questionnaire_metadatastandardproperty', (
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('field_type', self.gf('django.db.models.fields.CharField')(max_length=64, blank=True)),
            ('is_label', self.gf('django.db.models.fields.BooleanField')(default=False)),
            ('model', self.gf('django.db.models.fields.related.ForeignKey')(related_name='standard_properties', null=True, to=orm['questionnaire.MetadataModel'])),
            ('proxy', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['questionnaire.MetadataStandardPropertyProxy'], null=True, blank=True)),
            ('atomic_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('enumeration_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('enumeration_other_value', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('relationship_value', self.gf('django.db.models.fields.related.ForeignKey')(to=orm['questionnaire.MetadataModel'], null=True, blank=True)),
        ))
        db.send_create_signal('questionnaire', ['MetadataStandardProperty'])

        # Deleting field 'MetadataScientificPropertyCustomizer.inherited'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'inherited')

        # Deleting field 'MetadataScientificPropertyCustomizer.suggestions'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'suggestions')

        # Adding field 'MetadataScientificPropertyCustomizer.created'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'created',
                      self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.inline_help'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'inline_help',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.vocabulary_key'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'vocabulary_key',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.component_key'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'component_key',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.model_key'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'model_key',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.is_enumeration'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'is_enumeration',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.category'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'category',
                      self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='scientific_property_customizers', null=True, to=orm['questionnaire.MetadataScientificCategoryCustomizer']),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.category_name'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'category_name',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.atomic_type'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'atomic_type',
                      self.gf('django.db.models.fields.CharField')(default='DEFAULT', max_length=512, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.atomic_default'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'atomic_default',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.enumeration_choices'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_choices',
                      self.gf('questionnaire.fields.EnumerationField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.enumeration_default'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_default',
                      self.gf('questionnaire.fields.EnumerationField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.enumeration_open'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_open',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.enumeration_multi'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_multi',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.enumeration_nullable'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_nullable',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.display_extra_standard_name'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_standard_name',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.display_extra_description'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_description',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.display_extra_units'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_units',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.edit_extra_standard_name'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_standard_name',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.edit_extra_description'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_description',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.edit_extra_units'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_units',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.extra_standard_name'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_standard_name',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.extra_description'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_description',
                      self.gf('django.db.models.fields.TextField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.extra_units'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_units',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataModelCustomizer.created'
        db.add_column(u'questionnaire_metadatamodelcustomizer', 'created',
                      self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataModelCustomizer.vocabulary_order'
        db.add_column(u'questionnaire_metadatamodelcustomizer', 'vocabulary_order',
                      self.gf('django.db.models.fields.CommaSeparatedIntegerField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataModelCustomizer.model_hierarchy_name'
        db.add_column(u'questionnaire_metadatamodelcustomizer', 'model_hierarchy_name',
                      self.gf('django.db.models.fields.CharField')(default='Component Hierarchy', max_length=128),
                      keep_default=False)

        # Deleting field 'MetadataStandardPropertyProxy.relationship_target_model_name'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_model_name')

        # Adding field 'MetadataStandardPropertyProxy.is_label'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'is_label',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyProxy.atomic_type'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'atomic_type',
                      self.gf('django.db.models.fields.CharField')(default='DEFAULT', max_length=64),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyProxy.relationship_cardinality'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_cardinality',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=128, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyProxy.relationship_target_name'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=512, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyProxy.relationship_target_model'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_model',
                      self.gf('django.db.models.fields.related.ForeignKey')(to=orm['questionnaire.MetadataModelProxy'], null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataVocabulary.document_type'
        db.add_column(u'questionnaire_metadatavocabulary', 'document_type',
                      self.gf('django.db.models.fields.CharField')(default='modelcomponent', max_length=64),
                      keep_default=False)

        # Adding field 'MetadataModelProxy.stereotype'
        db.add_column(u'questionnaire_metadatamodelproxy', 'stereotype',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.created'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'created',
                      self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.inline_help'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'inline_help',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.category_name'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'category_name',
                      self.gf('django.db.models.fields.CharField')(max_length=512, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.atomic_type'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'atomic_type',
                      self.gf('django.db.models.fields.CharField')(default='DEFAULT', max_length=512, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.enumeration_choices'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_choices',
                      self.gf('questionnaire.fields.EnumerationField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.enumeration_default'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_default',
                      self.gf('questionnaire.fields.EnumerationField')(null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.enumeration_open'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_open',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.enumeration_multi'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_multi',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.enumeration_nullable'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_nullable',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.relationship_cardinality'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'relationship_cardinality',
                      self.gf('questionnaire.fields.CardinalityField')(default='', max_length=8, blank=True),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.relationship_show_subform'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'relationship_show_subform',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataStandardPropertyCustomizer.subform_customizer'
        db.add_column(u'questionnaire_metadatastandardpropertycustomizer', 'subform_customizer',
                      self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='property_customizer', null=True, to=orm['questionnaire.MetadataModelCustomizer']),
                      keep_default=False)

        # Deleting field 'MetadataScientificPropertyProxy.model_proxy'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'model_proxy_id')

        # Adding field 'MetadataScientificPropertyProxy.is_label'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'is_label',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyProxy.component'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'component',
                      self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='scientific_properties', null=True, to=orm['questionnaire.MetadataComponentProxy']),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyProxy.category'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'category',
                      self.gf('django.db.models.fields.related.ForeignKey')(blank=True, related_name='scientific_properties', null=True, to=orm['questionnaire.MetadataScientificCategoryProxy']),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyProxy.choice'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'choice',
                      self.gf('django.db.models.fields.CharField')(max_length=128, null=True, blank=True),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyProxy.values'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'values',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=1024, blank=True),
                      keep_default=False)

        # Adding unique constraint on 'MetadataScientificPropertyProxy', fields ['component', 'category', 'name']
        db.create_unique(u'questionnaire_metadatascientificpropertyproxy', ['component_id', 'category_id', 'name'])

        # Adding field 'MetadataStandardCategoryCustomizer.created'
        db.add_column(u'questionnaire_metadatastandardcategorycustomizer', 'created',
                      self.gf('django.db.models.fields.DateTimeField')(null=True, blank=True),
                      keep_default=False)

        # Adding unique constraint on 'MetadataStandardCategoryCustomizer', fields ['name', 'project', 'proxy', 'model_customizer']
        db.create_unique(u'questionnaire_metadatastandardcategorycustomizer', ['name', 'project_id', 'proxy_id', 'model_customizer_id'])


    def backwards(self, orm):
        # Removing unique constraint on 'MetadataStandardCategoryCustomizer', fields ['name', 'project', 'proxy', 'model_customizer']
        db.delete_unique(u'questionnaire_metadatastandardcategorycustomizer', ['name', 'project_id', 'proxy_id', 'model_customizer_id'])

        # Removing unique constraint on 'MetadataScientificPropertyProxy', fields ['component', 'category', 'name']
        db.delete_unique(u'questionnaire_metadatascientificpropertyproxy', ['component_id', 'category_id', 'name'])

        # Removing unique constraint on 'MetadataComponentProxy', fields ['vocabulary', 'name']
        db.delete_unique(u'questionnaire_metadatacomponentproxy', ['vocabulary_id', 'name'])

        # Removing unique constraint on 'MetadataScientificCategoryProxy', fields ['component', 'name']
        db.delete_unique(u'questionnaire_metadatascientificcategoryproxy', ['component_id', 'name'])

        # Removing unique constraint on 'MetadataScientificCategoryCustomizer', fields ['name', 'project', 'proxy', 'vocabulary_key', 'component_key', 'model_customizer']
        db.delete_unique(u'questionnaire_metadatascientificcategorycustomizer', ['name', 'project_id', 'proxy_id', 'vocabulary_key', 'component_key', 'model_customizer_id'])

        # Adding model 'NewModel'
        db.create_table(u'questionnaire_newmodel', (
            (u'lft', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
            ('parent', self.gf('mptt.fields.TreeForeignKey')(related_name='children', null=True, to=orm['questionnaire.NewModel'], blank=True)),
            (u'level', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'tree_id', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'rght', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
        ))
        db.send_create_signal('questionnaire', ['NewModel'])

        # Adding model 'MyModel'
        db.create_table(u'questionnaire_mymodel', (
            ('description', self.gf('django.db.models.fields.CharField')(max_length=1024, null=True, blank=True)),
            ('parent_model', self.gf('django.db.models.fields.related.ForeignKey')(related_name='child_models', null=True, to=orm['questionnaire.MyModel'], blank=True)),
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('version', self.gf('django.db.models.fields.related.ForeignKey')(related_name='models', null=True, to=orm['questionnaire.MetadataVersion'])),
            ('order', self.gf('django.db.models.fields.PositiveIntegerField')(null=True, blank=True)),
            ('name', self.gf('django.db.models.fields.CharField')(max_length=256)),
        ))
        db.send_create_signal('questionnaire', ['MyModel'])

        # Adding model 'TreeModel'
        db.create_table(u'questionnaire_treemodel', (
            (u'rght', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            ('parent', self.gf('mptt.fields.TreeForeignKey')(related_name='children', null=True, to=orm['questionnaire.TreeModel'], blank=True)),
            (u'level', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'lft', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'tree_id', self.gf('django.db.models.fields.PositiveIntegerField')(db_index=True)),
            (u'id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
        ))
        db.send_create_signal('questionnaire', ['TreeModel'])

        # Deleting model 'MetadataModel'
        db.delete_table(u'questionnaire_metadatamodel')

        # Deleting model 'MetadataScientificCategoryCustomizer'
        db.delete_table(u'questionnaire_metadatascientificcategorycustomizer')

        # Deleting model 'MetadataScientificCategoryProxy'
        db.delete_table(u'questionnaire_metadatascientificcategoryproxy')

        # Deleting model 'MetadataComponentProxy'
        db.delete_table(u'questionnaire_metadatacomponentproxy')

        # Deleting model 'MetadataScientificProperty'
        db.delete_table(u'questionnaire_metadatascientificproperty')

        # Deleting model 'MetadataStandardProperty'
        db.delete_table(u'questionnaire_metadatastandardproperty')

        # Adding field 'MetadataScientificPropertyCustomizer.inherited'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'inherited',
                      self.gf('django.db.models.fields.BooleanField')(default=False),
                      keep_default=False)

        # Adding field 'MetadataScientificPropertyCustomizer.suggestions'
        db.add_column(u'questionnaire_metadatascientificpropertycustomizer', 'suggestions',
                      self.gf('django.db.models.fields.TextField')(default='', blank=True),
                      keep_default=False)

        # Deleting field 'MetadataScientificPropertyCustomizer.created'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'created')

        # Deleting field 'MetadataScientificPropertyCustomizer.inline_help'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'inline_help')

        # Deleting field 'MetadataScientificPropertyCustomizer.vocabulary_key'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'vocabulary_key')

        # Deleting field 'MetadataScientificPropertyCustomizer.component_key'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'component_key')

        # Deleting field 'MetadataScientificPropertyCustomizer.model_key'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'model_key')

        # Deleting field 'MetadataScientificPropertyCustomizer.is_enumeration'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'is_enumeration')

        # Deleting field 'MetadataScientificPropertyCustomizer.category'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'category_id')

        # Deleting field 'MetadataScientificPropertyCustomizer.category_name'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'category_name')

        # Deleting field 'MetadataScientificPropertyCustomizer.atomic_type'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'atomic_type')

        # Deleting field 'MetadataScientificPropertyCustomizer.atomic_default'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'atomic_default')

        # Deleting field 'MetadataScientificPropertyCustomizer.enumeration_choices'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_choices')

        # Deleting field 'MetadataScientificPropertyCustomizer.enumeration_default'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_default')

        # Deleting field 'MetadataScientificPropertyCustomizer.enumeration_open'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_open')

        # Deleting field 'MetadataScientificPropertyCustomizer.enumeration_multi'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_multi')

        # Deleting field 'MetadataScientificPropertyCustomizer.enumeration_nullable'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'enumeration_nullable')

        # Deleting field 'MetadataScientificPropertyCustomizer.display_extra_standard_name'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_standard_name')

        # Deleting field 'MetadataScientificPropertyCustomizer.display_extra_description'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_description')

        # Deleting field 'MetadataScientificPropertyCustomizer.display_extra_units'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'display_extra_units')

        # Deleting field 'MetadataScientificPropertyCustomizer.edit_extra_standard_name'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_standard_name')

        # Deleting field 'MetadataScientificPropertyCustomizer.edit_extra_description'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_description')

        # Deleting field 'MetadataScientificPropertyCustomizer.edit_extra_units'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'edit_extra_units')

        # Deleting field 'MetadataScientificPropertyCustomizer.extra_standard_name'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_standard_name')

        # Deleting field 'MetadataScientificPropertyCustomizer.extra_description'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_description')

        # Deleting field 'MetadataScientificPropertyCustomizer.extra_units'
        db.delete_column(u'questionnaire_metadatascientificpropertycustomizer', 'extra_units')

        # Deleting field 'MetadataModelCustomizer.created'
        db.delete_column(u'questionnaire_metadatamodelcustomizer', 'created')

        # Deleting field 'MetadataModelCustomizer.vocabulary_order'
        db.delete_column(u'questionnaire_metadatamodelcustomizer', 'vocabulary_order')

        # Deleting field 'MetadataModelCustomizer.model_hierarchy_name'
        db.delete_column(u'questionnaire_metadatamodelcustomizer', 'model_hierarchy_name')

        # Adding field 'MetadataStandardPropertyProxy.relationship_target_model_name'
        db.add_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_model_name',
                      self.gf('django.db.models.fields.CharField')(default='', max_length=512, blank=True),
                      keep_default=False)

        # Deleting field 'MetadataStandardPropertyProxy.is_label'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'is_label')

        # Deleting field 'MetadataStandardPropertyProxy.atomic_type'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'atomic_type')

        # Deleting field 'MetadataStandardPropertyProxy.relationship_cardinality'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_cardinality')

        # Deleting field 'MetadataStandardPropertyProxy.relationship_target_name'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_name')

        # Deleting field 'MetadataStandardPropertyProxy.relationship_target_model'
        db.delete_column(u'questionnaire_metadatastandardpropertyproxy', 'relationship_target_model_id')

        # Deleting field 'MetadataVocabulary.document_type'
        db.delete_column(u'questionnaire_metadatavocabulary', 'document_type')

        # Deleting field 'MetadataModelProxy.stereotype'
        db.delete_column(u'questionnaire_metadatamodelproxy', 'stereotype')

        # Deleting field 'MetadataStandardPropertyCustomizer.created'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'created')

        # Deleting field 'MetadataStandardPropertyCustomizer.inline_help'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'inline_help')

        # Deleting field 'MetadataStandardPropertyCustomizer.category_name'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'category_name')

        # Deleting field 'MetadataStandardPropertyCustomizer.atomic_type'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'atomic_type')

        # Deleting field 'MetadataStandardPropertyCustomizer.enumeration_choices'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_choices')

        # Deleting field 'MetadataStandardPropertyCustomizer.enumeration_default'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_default')

        # Deleting field 'MetadataStandardPropertyCustomizer.enumeration_open'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_open')

        # Deleting field 'MetadataStandardPropertyCustomizer.enumeration_multi'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_multi')

        # Deleting field 'MetadataStandardPropertyCustomizer.enumeration_nullable'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'enumeration_nullable')

        # Deleting field 'MetadataStandardPropertyCustomizer.relationship_cardinality'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'relationship_cardinality')

        # Deleting field 'MetadataStandardPropertyCustomizer.relationship_show_subform'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'relationship_show_subform')

        # Deleting field 'MetadataStandardPropertyCustomizer.subform_customizer'
        db.delete_column(u'questionnaire_metadatastandardpropertycustomizer', 'subform_customizer_id')

        # Adding field 'MetadataScientificPropertyProxy.model_proxy'
        db.add_column(u'questionnaire_metadatascientificpropertyproxy', 'model_proxy',
                      self.gf('django.db.models.fields.related.ForeignKey')(related_name='scientific_properties', null=True, to=orm['questionnaire.MetadataModelProxy'], blank=True),
                      keep_default=False)

        # Deleting field 'MetadataScientificPropertyProxy.is_label'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'is_label')

        # Deleting field 'MetadataScientificPropertyProxy.component'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'component_id')

        # Deleting field 'MetadataScientificPropertyProxy.category'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'category_id')

        # Deleting field 'MetadataScientificPropertyProxy.choice'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'choice')

        # Deleting field 'MetadataScientificPropertyProxy.values'
        db.delete_column(u'questionnaire_metadatascientificpropertyproxy', 'values')

        # Adding unique constraint on 'MetadataScientificPropertyProxy', fields ['model_proxy', 'name']
        db.create_unique(u'questionnaire_metadatascientificpropertyproxy', ['model_proxy_id', 'name'])

        # Deleting field 'MetadataStandardCategoryCustomizer.created'
        db.delete_column(u'questionnaire_metadatastandardcategorycustomizer', 'created')

        # Adding unique constraint on 'MetadataStandardCategoryCustomizer', fields ['name', 'project', 'proxy']
        db.create_unique(u'questionnaire_metadatastandardcategorycustomizer', ['name', 'project_id', 'proxy_id'])


    models = {
        u'auth.group': {
            'Meta': {'object_name': 'Group'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '80'}),
            'permissions': ('django.db.models.fields.related.ManyToManyField', [], {'to': u"orm['auth.Permission']", 'symmetrical': 'False', 'blank': 'True'})
        },
        u'auth.permission': {
            'Meta': {'ordering': "(u'content_type__app_label', u'content_type__model', u'codename')", 'unique_together': "((u'content_type', u'codename'),)", 'object_name': 'Permission'},
            'codename': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'content_type': ('django.db.models.fields.related.ForeignKey', [], {'to': u"orm['contenttypes.ContentType']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        },
        u'auth.user': {
            'Meta': {'object_name': 'User'},
            'date_joined': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'blank': 'True'}),
            'first_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'groups': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "u'user_set'", 'blank': 'True', 'to': u"orm['auth.Group']"}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'is_staff': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_superuser': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_login': ('django.db.models.fields.DateTimeField', [], {'default': 'datetime.datetime.now'}),
            'last_name': ('django.db.models.fields.CharField', [], {'max_length': '30', 'blank': 'True'}),
            'password': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'user_permissions': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'related_name': "u'user_set'", 'blank': 'True', 'to': u"orm['auth.Permission']"}),
            'username': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '30'})
        },
        u'contenttypes.contenttype': {
            'Meta': {'ordering': "('name',)", 'unique_together': "(('app_label', 'model'),)", 'object_name': 'ContentType', 'db_table': "'django_content_type'"},
            'app_label': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'model': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '100'})
        },
        'questionnaire.metadatacategorization': {
            'Meta': {'object_name': 'MetadataCategorization'},
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '256'}),
            'registered': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        'questionnaire.metadatacomponentproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('vocabulary', 'name'),)", 'object_name': 'MetadataComponentProxy'},
            'documentation': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            u'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            u'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['questionnaire.MetadataComponentProxy']"}),
            u'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            u'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'vocabulary': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'component_proxies'", 'null': 'True', 'to': "orm['questionnaire.MetadataVocabulary']"})
        },
        'questionnaire.metadatamodel': {
            'Meta': {'object_name': 'MetadataModel'},
            'active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'component_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'description': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_document': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_root': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            u'level': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            u'lft': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'parent': ('mptt.fields.TreeForeignKey', [], {'blank': 'True', 'related_name': "'children'", 'null': 'True', 'to': "orm['questionnaire.MetadataModel']"}),
            'project': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'models'", 'null': 'True', 'to': "orm['questionnaire.MetadataProject']"}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'models'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelProxy']"}),
            u'rght': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            u'tree_id': ('django.db.models.fields.PositiveIntegerField', [], {'db_index': 'True'}),
            'version': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'models'", 'null': 'True', 'to': "orm['questionnaire.MetadataVersion']"}),
            'vocabulary_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatamodelcustomizer': {
            'Meta': {'unique_together': "(('name', 'project', 'version', 'proxy'),)", 'object_name': 'MetadataModelCustomizer'},
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'default': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'model_description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            'model_hierarchy_name': ('django.db.models.fields.CharField', [], {'default': "'Component Hierarchy'", 'max_length': '128'}),
            'model_root_component': ('django.db.models.fields.CharField', [], {'default': "'RootComponent'", 'max_length': '128', 'blank': 'True'}),
            'model_show_all_categories': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'model_show_all_properties': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'model_show_hierarchy': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'model_title': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'project': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'model_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataProject']"}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataModelProxy']", 'null': 'True', 'blank': 'True'}),
            'version': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'model_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataVersion']"}),
            'vocabularies': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['questionnaire.MetadataVocabulary']", 'null': 'True', 'blank': 'True'}),
            'vocabulary_order': ('django.db.models.fields.CommaSeparatedIntegerField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatamodelproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('version', 'name'),)", 'object_name': 'MetadataModelProxy'},
            'documentation': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'package': ('django.db.models.fields.CharField', [], {'max_length': '256', 'null': 'True', 'blank': 'True'}),
            'stereotype': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True'}),
            'version': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'model_proxies'", 'null': 'True', 'to': "orm['questionnaire.MetadataVersion']"})
        },
        'questionnaire.metadataopenidprovider': {
            'Meta': {'object_name': 'MetadataOpenIDProvider'},
            'active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'icon': ('django.db.models.fields.files.ImageField', [], {'max_length': '100', 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '128'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'url': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '256'})
        },
        'questionnaire.metadataproject': {
            'Meta': {'object_name': 'MetadataProject'},
            'active': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'authenticated': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'description': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'email': ('django.db.models.fields.EmailField', [], {'max_length': '75', 'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '255'}),
            'providers': ('django.db.models.fields.related.ManyToManyField', [], {'to': "orm['questionnaire.MetadataOpenIDProvider']", 'symmetrical': 'False', 'blank': 'True'}),
            'title': ('django.db.models.fields.CharField', [], {'max_length': '255'}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200', 'blank': 'True'}),
            'vocabularies': ('django.db.models.fields.related.ManyToManyField', [], {'symmetrical': 'False', 'to': "orm['questionnaire.MetadataVocabulary']", 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatascientificcategorycustomizer': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('name', 'project', 'proxy', 'vocabulary_key', 'component_key', 'model_customizer'),)", 'object_name': 'MetadataScientificCategoryCustomizer'},
            'component_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'model_customizer': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'scientific_property_category_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelCustomizer']"}),
            'model_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'pending_deletion': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'project': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'model_scientific_category_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataProject']"}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataScientificCategoryProxy']", 'null': 'True', 'blank': 'True'}),
            'vocabulary_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatascientificcategoryproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('component', 'name'),)", 'object_name': 'MetadataScientificCategoryProxy'},
            'component': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'categories'", 'null': 'True', 'to': "orm['questionnaire.MetadataComponentProxy']"}),
            'description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'key': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatascientificproperty': {
            'Meta': {'ordering': "['order']", 'object_name': 'MetadataScientificProperty'},
            'atomic_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'category_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'enumeration_other_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'enumeration_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'extra_description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            'extra_standard_name': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'extra_units': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '64', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_enumeration': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_label': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'model': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'scientific_properties'", 'null': 'True', 'to': "orm['questionnaire.MetadataModel']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataScientificPropertyProxy']", 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatascientificpropertycustomizer': {
            'Meta': {'ordering': "['order']", 'object_name': 'MetadataScientificPropertyCustomizer'},
            'atomic_default': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'atomic_type': ('django.db.models.fields.CharField', [], {'default': "'DEFAULT'", 'max_length': '512', 'blank': 'True'}),
            'category': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'scientific_property_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataScientificCategoryCustomizer']"}),
            'category_name': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'component_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'default_value': ('django.db.models.fields.CharField', [], {'max_length': '128', 'null': 'True', 'blank': 'True'}),
            'display_extra_description': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'display_extra_standard_name': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'display_extra_units': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'displayed': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'documentation': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'edit_extra_description': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'edit_extra_standard_name': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'edit_extra_units': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'editable': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'enumeration_choices': ('questionnaire.fields.EnumerationField', [], {'null': 'True', 'blank': 'True'}),
            'enumeration_default': ('questionnaire.fields.EnumerationField', [], {'null': 'True', 'blank': 'True'}),
            'enumeration_multi': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_nullable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_open': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'extra_description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            'extra_standard_name': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'extra_units': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '64', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'inline_help': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'is_enumeration': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'model_customizer': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'scientific_property_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelCustomizer']"}),
            'model_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataScientificPropertyProxy']", 'null': 'True', 'blank': 'True'}),
            'required': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'unique': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'verbose_name': ('django.db.models.fields.CharField', [], {'max_length': '64'}),
            'vocabulary_key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatascientificpropertyproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('component', 'category', 'name'),)", 'object_name': 'MetadataScientificPropertyProxy'},
            'category': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'scientific_properties'", 'null': 'True', 'to': "orm['questionnaire.MetadataScientificCategoryProxy']"}),
            'choice': ('django.db.models.fields.CharField', [], {'max_length': '128', 'null': 'True', 'blank': 'True'}),
            'component': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'scientific_properties'", 'null': 'True', 'to': "orm['questionnaire.MetadataComponentProxy']"}),
            'documentation': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '256', 'null': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_label': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'values': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'blank': 'True'})
        },
        'questionnaire.metadatasite': {
            'Meta': {'object_name': 'MetadataSite'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'site': ('django.db.models.fields.related.OneToOneField', [], {'related_name': "'metadata_site'", 'unique': 'True', 'to': u"orm['sites.Site']"}),
            'type': ('django.db.models.fields.CharField', [], {'max_length': '256', 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatastandardcategorycustomizer': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('name', 'project', 'proxy', 'model_customizer'),)", 'object_name': 'MetadataStandardCategoryCustomizer'},
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'key': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'model_customizer': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'standard_property_category_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelCustomizer']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'pending_deletion': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'project': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'model_standard_category_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataProject']"}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataStandardCategoryProxy']", 'null': 'True', 'blank': 'True'}),
            'version': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'model_standard_category_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataVersion']"})
        },
        'questionnaire.metadatastandardcategoryproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('categorization', 'name'),)", 'object_name': 'MetadataStandardCategoryProxy'},
            'categorization': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'categories'", 'to': "orm['questionnaire.MetadataCategorization']"}),
            'description': ('django.db.models.fields.TextField', [], {'null': 'True', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'key': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'properties': ('django.db.models.fields.related.ManyToManyField', [], {'blank': 'True', 'related_name': "'category'", 'null': 'True', 'symmetrical': 'False', 'to': "orm['questionnaire.MetadataStandardPropertyProxy']"})
        },
        'questionnaire.metadatastandardproperty': {
            'Meta': {'ordering': "['order']", 'object_name': 'MetadataStandardProperty'},
            'atomic_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'enumeration_other_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'enumeration_value': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'null': 'True', 'blank': 'True'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '64', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_label': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'model': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'standard_properties'", 'null': 'True', 'to': "orm['questionnaire.MetadataModel']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataStandardPropertyProxy']", 'null': 'True', 'blank': 'True'}),
            'relationship_value': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataModel']", 'null': 'True', 'blank': 'True'})
        },
        'questionnaire.metadatastandardpropertycustomizer': {
            'Meta': {'ordering': "['order']", 'object_name': 'MetadataStandardPropertyCustomizer'},
            'atomic_type': ('django.db.models.fields.CharField', [], {'default': "'DEFAULT'", 'max_length': '512', 'blank': 'True'}),
            'category': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'standard_property_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataStandardCategoryCustomizer']"}),
            'category_name': ('django.db.models.fields.CharField', [], {'max_length': '512', 'null': 'True', 'blank': 'True'}),
            'created': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'default_value': ('django.db.models.fields.CharField', [], {'max_length': '128', 'null': 'True', 'blank': 'True'}),
            'displayed': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'documentation': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'editable': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'enumeration_choices': ('questionnaire.fields.EnumerationField', [], {'null': 'True', 'blank': 'True'}),
            'enumeration_default': ('questionnaire.fields.EnumerationField', [], {'null': 'True', 'blank': 'True'}),
            'enumeration_multi': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_nullable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_open': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '64', 'blank': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'inherited': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'inline_help': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'last_modified': ('django.db.models.fields.DateTimeField', [], {'null': 'True', 'blank': 'True'}),
            'model_customizer': ('django.db.models.fields.related.ForeignKey', [], {'related_name': "'standard_property_customizers'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelCustomizer']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '256'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'proxy': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataStandardPropertyProxy']", 'null': 'True', 'blank': 'True'}),
            'relationship_cardinality': ('questionnaire.fields.CardinalityField', [], {'max_length': '8', 'blank': 'True'}),
            'relationship_show_subform': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'required': ('django.db.models.fields.BooleanField', [], {'default': 'True'}),
            'subform_customizer': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'property_customizer'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelCustomizer']"}),
            'suggestions': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'unique': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'verbose_name': ('django.db.models.fields.CharField', [], {'max_length': '64'})
        },
        'questionnaire.metadatastandardpropertyproxy': {
            'Meta': {'ordering': "['order']", 'unique_together': "(('model_proxy', 'name'),)", 'object_name': 'MetadataStandardPropertyProxy'},
            'atomic_default': ('django.db.models.fields.CharField', [], {'max_length': '512', 'blank': 'True'}),
            'atomic_type': ('django.db.models.fields.CharField', [], {'default': "'DEFAULT'", 'max_length': '64'}),
            'documentation': ('django.db.models.fields.TextField', [], {'blank': 'True'}),
            'enumeration_choices': ('django.db.models.fields.CharField', [], {'max_length': '1024', 'blank': 'True'}),
            'enumeration_multi': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_nullable': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'enumeration_open': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'field_type': ('django.db.models.fields.CharField', [], {'max_length': '256', 'null': 'True'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'is_label': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'model_proxy': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'standard_properties'", 'null': 'True', 'to': "orm['questionnaire.MetadataModelProxy']"}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '512'}),
            'order': ('django.db.models.fields.PositiveIntegerField', [], {'null': 'True', 'blank': 'True'}),
            'relationship_cardinality': ('django.db.models.fields.CharField', [], {'max_length': '128', 'blank': 'True'}),
            'relationship_target_model': ('django.db.models.fields.related.ForeignKey', [], {'to': "orm['questionnaire.MetadataModelProxy']", 'null': 'True', 'blank': 'True'}),
            'relationship_target_name': ('django.db.models.fields.CharField', [], {'max_length': '512', 'blank': 'True'})
        },
        'questionnaire.metadatauser': {
            'Meta': {'object_name': 'MetadataUser'},
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'projects': ('django.db.models.fields.related.ManyToManyField', [], {'blank': 'True', 'related_name': "'metadata_user'", 'null': 'True', 'symmetrical': 'False', 'to': "orm['questionnaire.MetadataProject']"}),
            'user': ('django.db.models.fields.related.OneToOneField', [], {'related_name': "'metadata_user'", 'unique': 'True', 'to': u"orm['auth.User']"})
        },
        'questionnaire.metadataversion': {
            'Meta': {'object_name': 'MetadataVersion'},
            'categorization': ('django.db.models.fields.related.ForeignKey', [], {'blank': 'True', 'related_name': "'versions'", 'null': 'True', 'to': "orm['questionnaire.MetadataCategorization']"}),
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '256'}),
            'registered': ('django.db.models.fields.BooleanField', [], {'default': 'False'}),
            'url': ('django.db.models.fields.URLField', [], {'max_length': '200', 'blank': 'True'})
        },
        'questionnaire.metadatavocabulary': {
            'Meta': {'object_name': 'MetadataVocabulary'},
            'document_type': ('django.db.models.fields.CharField', [], {'max_length': '64'}),
            'file': ('django.db.models.fields.files.FileField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'unique': 'True', 'max_length': '256'}),
            'registered': ('django.db.models.fields.BooleanField', [], {'default': 'False'})
        },
        u'sites.site': {
            'Meta': {'ordering': "(u'domain',)", 'object_name': 'Site', 'db_table': "u'django_site'"},
            'domain': ('django.db.models.fields.CharField', [], {'max_length': '100'}),
            u'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'name': ('django.db.models.fields.CharField', [], {'max_length': '50'})
        }
    }

    complete_apps = ['questionnaire']