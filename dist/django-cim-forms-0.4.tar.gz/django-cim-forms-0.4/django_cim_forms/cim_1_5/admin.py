from django.contrib import admin

from models import *

admin.site.register(Calendar)
admin.site.register(NumericalRequirement)
admin.site.register(CompositeNumericalRequirement)
