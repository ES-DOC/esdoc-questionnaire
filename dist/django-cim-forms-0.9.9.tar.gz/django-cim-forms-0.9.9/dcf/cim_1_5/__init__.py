# this is important!
# import the modules that define models and forms
# so that they are ready to be dynamically-loaded

# if you don't do this,
# icky things will happen

import dcf.cim_1_5.models
import dcf.cim_1_5.forms
