# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="allyn.treshansky"
__date__ ="$Nov 26, 2012 10:48:30 AM$"

if __name__ == "__main__":
    print "Hello World"
