from django.contrib.syndication.views import Feed

from models import *

class MetadataFeed(Feed):
    pass