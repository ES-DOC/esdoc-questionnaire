================
Django-CIM-Forms
================

Django-CIM-Forms is a Django Application that generates webforms based on CIM-compatible metadata models and controlled vocabularies for use in a Django Framework.

