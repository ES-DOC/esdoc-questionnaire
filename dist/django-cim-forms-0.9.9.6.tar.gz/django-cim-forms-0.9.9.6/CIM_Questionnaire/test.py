#! /usr/bin/python

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="allyn.treshansky"
__date__ ="$Oct 1, 2013 9:55:14 AM$"

if __name__ == "__main__":
    print "Hello World";

from questionnaire import *

print "la"