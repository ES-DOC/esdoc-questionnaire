/* custom js for the django_cim application */

function removeForm(data) {
  alert(data);
};

