BEGIN;
ALTER TABLE "dycore_dycoremodel_properties" DROP CONSTRAINT "dycoremodel_id_refs_modelcomponent_ptr_id_91eded42";
DROP TABLE "dycore_dycoremodel";
DROP TABLE "dycore_dycoremodel_properties";
DROP TABLE "dycore_dycorescientificproperty";
ALTER TABLE "dycore_dycorescientificproperties_cv" DROP CONSTRAINT "parent_id_refs_id_17ade218";
DROP TABLE "dycore_dycorescientificproperties_cv";
DROP TABLE "dycore_parallelization_enumeration";
DROP TABLE "dycore_dataformat_enumeration";

COMMIT;
