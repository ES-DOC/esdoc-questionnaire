# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="allyn.treshansky"
__date__ ="$Apr 25, 2012 3:43:53 PM$"

if __name__ == "__main__":
    print "Hello World"
