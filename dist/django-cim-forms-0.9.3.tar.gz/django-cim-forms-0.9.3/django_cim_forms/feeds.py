from django.contrib.syndication.views import Feed, FeedDoesNotExist
from django.utils.feedgenerator import Atom1Feed

from models import *

class MetadataFeed(Feed):
    feed_type = Atom1Feed
    title = "CIM Metadata Documents"
    link = "/feed/"

    ModelClass = None

##    def __init__(self,app_name,model_name):
##        super(MetadataFeed,self).__init__()
##        try:
##            ModelType  = ContentType.objects.get(app_label=app_name.lower(),model=model_name.lower())
##        except ObjectDoesNotExist:
##            msg = "invalid model type '%s' in application '%s'" % (model_name, app_name)
##            return HttpResponseBadRequest(msg)
##        self.ModelClass = ModelType.model_class()
##
##
##    def items(self):
##
##
##        return self.ModelClass.objects.order_by("-created")
